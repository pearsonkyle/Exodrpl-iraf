Version 1.0

Created by Kyle Pearson

GNU Public Liscense v3.0

To Run:
type in terminal: ./RUN

